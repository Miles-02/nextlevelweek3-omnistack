<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Endereco extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Endereco_model');
    } 

    /*
     * Listing of endereco
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('endereco/index?');
        $config['total_rows'] = $this->Endereco_model->get_all_endereco_count();
        $this->pagination->initialize($config);

        $data['endereco'] = $this->Endereco_model->get_all_endereco($params);
        
        $data['_view'] = 'endereco/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new endereco
     */
    function add()
    {   
        if(isset($_POST) && count($_POST) > 0)     
        {   
            $params = array(
				'rua' => $this->input->post('rua'),
				'numero' => $this->input->post('numero'),
				'bairro' => $this->input->post('bairro'),
				'cidade' => $this->input->post('cidade'),
				'estado' => $this->input->post('estado'),
				'cep' => $this->input->post('cep'),
            );
            
            $endereco_id = $this->Endereco_model->add_endereco($params);
            redirect('endereco/index');
        }
        else
        {            
            $data['_view'] = 'endereco/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a endereco
     */
    function edit($idendereco)
    {   
        // check if the endereco exists before trying to edit it
        $data['endereco'] = $this->Endereco_model->get_endereco($idendereco);
        
        if(isset($data['endereco']['idendereco']))
        {
            if(isset($_POST) && count($_POST) > 0)     
            {   
                $params = array(
					'rua' => $this->input->post('rua'),
					'numero' => $this->input->post('numero'),
					'bairro' => $this->input->post('bairro'),
					'cidade' => $this->input->post('cidade'),
					'estado' => $this->input->post('estado'),
					'cep' => $this->input->post('cep'),
                );

                $this->Endereco_model->update_endereco($idendereco,$params);            
                redirect('endereco/index');
            }
            else
            {
                $data['_view'] = 'endereco/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The endereco you are trying to edit does not exist.');
    } 

    /*
     * Deleting endereco
     */
    function remove($idendereco)
    {
        $endereco = $this->Endereco_model->get_endereco($idendereco);

        // check if the endereco exists before trying to delete it
        if(isset($endereco['idendereco']))
        {
            $this->Endereco_model->delete_endereco($idendereco);
            redirect('endereco/index');
        }
        else
            show_error('The endereco you are trying to delete does not exist.');
    }
    
}
