<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Comanda extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Comanda_model');
    } 

    /*
     * Listing of comanda
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('comanda/index?');
        $config['total_rows'] = $this->Comanda_model->get_all_comanda_count();
        $this->pagination->initialize($config);

        $data['comanda'] = $this->Comanda_model->get_all_comanda($params);
        
        $data['_view'] = 'comanda/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new comanda
     */
    function add()
    {   
        if(isset($_POST) && count($_POST) > 0)     
        {   
            $params = array(
				'data' => $this->input->post('data'),
				'quantidade' => $this->input->post('quantidade'),
				'total' => $this->input->post('total'),
                'status' => 1,
                'evento_idevento' => 2,
				'produto_idproduto' => $this->input->post('produto_idproduto'),
				'cartao_idcartao' => $this->input->post('cartao_idcartao'),
            );
            
            $comanda_id = $this->Comanda_model->add_comanda($params);
            redirect('comanda/index');
        }
        else
        {
            $this->load->model('Produto_model');
            $data['all_produto'] = $this->Produto_model->get_all_produto();

            $data['_view'] = 'comanda/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a comanda
     */
    function edit($idcomanda)
    {   
        // check if the comanda exists before trying to edit it
        $data['comanda'] = $this->Comanda_model->get_comanda($idcomanda);
        
        if(isset($data['comanda']['idcomanda']))
        {
            if(isset($_POST) && count($_POST) > 0)     
            {   
                $params = array(
					'data' => $this->input->post('data'),
					'status' => $this->input->post('status'),
					'total' => $this->input->post('total'),
					'produto_idproduto' => $this->input->post('produto_idproduto'),
					'cartao_idcartao' => $this->input->post('cartao_idcartao'),
					'funcionario_idfuncionario' => $this->input->post('funcionario_idfuncionario'),
                );

                $this->Comanda_model->update_comanda($idcomanda,$params);            
                redirect('comanda/index');
            }
            else
            {
                $data['_view'] = 'comanda/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The comanda you are trying to edit does not exist.');
    } 

    function remove($idcomanda)
    {
        $comanda = $this->Comanda_model->get_comanda($idcomanda);

        // check if the comanda exists before trying to delete it
        if(isset($comanda['idcomanda']))
        {
            $this->Comanda_model->delete_comanda($idcomanda);
            redirect('comanda/index');
        }
        else
            show_error('The comanda you are trying to delete does not exist.');
    }

    function estornar($idcomanda){
        $data['comanda'] = $this->Comanda_model->get_comanda($idcomanda);

        if(isset($data['comanda']['idcomanda']))
        {
            $params = array(
                'status' => 2,
            );

            $this->Comanda_model->update_comanda($idcomanda,$params);
            redirect('comanda/index');
        }
        else
            show_error('The comanda you are trying to edit does not exist.');
    }

    
    
}
