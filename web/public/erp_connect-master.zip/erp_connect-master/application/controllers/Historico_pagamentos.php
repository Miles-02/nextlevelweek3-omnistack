<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Historico_pagamentos extends CI_Controller
{

}