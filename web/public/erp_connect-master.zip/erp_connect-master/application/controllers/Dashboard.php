<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Dashboard extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Evento_model');
        $this->load->model('Comanda_model');

    }

    function index()
    {
        $usuario = $this->session->userdata('logged_in');
        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];
        $data['_view'] = 'dashboard';

        if($usuario['empresa']== 9999){
            $this->load->view('layouts/main2',$data);
        }else{
            $this->load->view('layouts/main',$data);
        }
    }
}
