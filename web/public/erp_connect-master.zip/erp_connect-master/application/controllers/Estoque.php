<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Estoque extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Estoque_model');
    } 

    /*
     * Listing of estoque
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('estoque/index?');
        $config['total_rows'] = $this->Estoque_model->get_all_estoque_count();
        $this->pagination->initialize($config);

        $data['estoque'] = $this->Estoque_model->get_all_estoque($params);
        
        $data['_view'] = 'estoque/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new estoque
     */
    function add()
    {   
        if(isset($_POST) && count($_POST) > 0)     
        {   
            $params = array(
				'quantidade' => $this->input->post('quantidade'),
				'produto_idproduto' => $this->input->post('produto_idproduto'),
            );
            
            $estoque_id = $this->Estoque_model->add_estoque($params);
            redirect('estoque/index');
        }
        else
        {
            $this->load->model('Produto_model');
            $data['all_produto'] = $this->Produto_model->get_all_produto();

            $data['_view'] = 'estoque/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a estoque
     */
    function edit($idestoque)
    {   
        // check if the estoque exists before trying to edit it
        $data['estoque'] = $this->Estoque_model->get_estoque($idestoque);
        
        if(isset($data['estoque']['idestoque']))
        {
            if(isset($_POST) && count($_POST) > 0)     
            {   
                $params = array(
					'quantidade' => $this->input->post('quantidade'),
					'produto_idproduto' => $this->input->post('produto_idproduto'),
                );

                $this->Estoque_model->update_estoque($idestoque,$params);            
                redirect('estoque/index');
            }
            else
            {
                $data['_view'] = 'estoque/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The estoque you are trying to edit does not exist.');
    } 

    /*
     * Deleting estoque
     */
    function remove($idestoque)
    {
        $estoque = $this->Estoque_model->get_estoque($idestoque);

        // check if the estoque exists before trying to delete it
        if(isset($estoque['idestoque']))
        {
            $this->Estoque_model->delete_estoque($idestoque);
            redirect('estoque/index');
        }
        else
            show_error('The estoque you are trying to delete does not exist.');
    }
    
}
