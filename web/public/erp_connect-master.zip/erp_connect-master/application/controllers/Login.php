<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->helper('form');
        $this->load->model('Login_model');
    }
    function login()
    {
        $this->load->view('login');
    }
    function index()
    {
        $this->load->view('login');
    }

    function autentica()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_message('required', 'campo %s obrigatório');
        $this->form_validation->set_rules('codigo', 'Usuário', 'trim|required');
        $this->form_validation->set_rules('senha', 'Senha', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            //FALHA DE VALIDAÇÃO.  Redirecionando para pagina de login
            redirect('login/login', 'refresh');
        } else {
            $codigo = $this->input->post('codigo');
            $senha = $this->input->post('senha');

            $result = $this->Login_model->logar($codigo, $senha);

            if ((isset($result)) && (!empty($result))) {
                $resultadoUsuario = $this->Login_model->logar($codigo, $senha);

                foreach ($resultadoUsuario as $usuario) {
                    $config_array = array(
                        'idfuncionario' => $usuario->idfuncionario,
                        'codigo' => $usuario->codigo,
                        'senha' => $usuario->senha,
                        'gerente' => $usuario->gerente,
                        'nome' => $usuario->nome,
                        'empresa' => $usuario->empresa_idempresa,
                    );
                }
                $this->session->set_userdata('logged_in', $config_array);
                redirect('dashboard');
            } else {
                redirect('login', 'refresh');
            }
        }
    }

    function logout()
    {
        $this->session->sess_destroy();
        redirect('login/login', 'refresh');
    }
}
