<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Retirada_caixa extends CI_Controller
{

}