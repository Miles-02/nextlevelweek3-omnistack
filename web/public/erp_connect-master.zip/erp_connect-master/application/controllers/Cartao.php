<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Cartao extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Cartao_model');
        $this->load->model('Cartaoevento_model');
    } 

    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('cartao/index?');
        $config['total_rows'] = $this->Cartao_model->get_all_cartao_count();
        $this->pagination->initialize($config);

        $data['cartao'] = $this->Cartao_model->get_all_cartao($params);
        
        $data['_view'] = 'cartao/index';
        $this->load->view('layouts/main',$data);
    }
    function add()
    {   
        if(isset($_POST) && count($_POST) > 0)     
        {   
            $params = array(
				'registro' => $this->input->post('registro'),
				'saldo' => $this->input->post('saldo'),
                'status' => 1,
				'cliente_idcliente' => $this->input->post('cliente_idcliente'),
            );
            
            $cartao_id = $this->Cartao_model->add_cartao($params);
            redirect('cartao/index');
        }
        else
        {            
            $data['_view'] = 'cartao/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    function edit($idcartao)
    {   
        // check if the cartao exists before trying to edit it
        $data['cartao'] = $this->Cartao_model->get_cartao($idcartao);
        
        if(isset($data['cartao']['idcartao']))
        {
            if(isset($_POST) && count($_POST) > 0)     
            {   
                $params = array(
					'registro' => $this->input->post('registro'),
					'saldo' => $this->input->post('saldo'),
					'cliente_idcliente' => $this->input->post('cliente_idcliente'),
                );

                $this->Cartao_model->update_cartao($idcartao,$params);            
                redirect('cartao/index');
            }
            else
            {
                $data['_view'] = 'cartao/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cartao you are trying to edit does not exist.');
    } 


    function desativar($idcartao){

        $data['cartao'] = $this->Cartao_model->get_cartao($idcartao);

        if(isset($data['cartao']['idcartao']))
        {
            $params = array(
                'status' => 0,
            );

            $this->Cartao_model->update_cartao($idcartao,$params);
            redirect('cartaoEvento/index');
        }
        else
            show_error('The evento you are trying to edit does not exist.');
    }
    function pesquisarCartao(){
        $registro = $this->input->post('registro');
        $cartao = $this->Cartao_model->pesquisarCartao($registro);

        if (!$cartao['registro']){
            $data['msg'] = "<br>Cartão não cadastrado, favor efetuar o resgistro";
            $data['_view'] = 'cartao/add';
            $this->load->view('layouts/main', $data);
            return;
        }else{
            $params = array(
                'cartao_idcartao' => $cartao['idcartao'],
                'evento_idevento'=> 2,
            );

            $cartaoEvento_id = $this->CartaoEvento_model->add_cartaoEvento($params);

            $data['cartao'] = $cartao;
            $data['_view'] = 'cartao/teste';
            $this->load->view('layouts/main', $data);
        }

    }
}
