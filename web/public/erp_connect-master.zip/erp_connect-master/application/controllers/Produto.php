<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Produto extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Produto_model');
    } 

    function index()
    {
        $usuario = $this->session->userdata('logged_in');
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('produto/index?');
        $config['total_rows'] = $this->Produto_model->get_all_produto_count();
        $this->pagination->initialize($config);

        $data['produto'] = $this->Produto_model->get_all_produto($params);
        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];
        
        $data['_view'] = 'produto/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new produto
     */
    function add()
    {   
        if(isset($_POST) && count($_POST) > 0)     
        {   
            $params = array(
				'nome' => $this->input->post('nome'),
				'descricao' => $this->input->post('descricao'),
                'valor' => $this->input->post('valor'),
                'categoria' => $this->input->post('categoria'),
                'img' => $this->input->post('img')
            );
            
            $produto_id = $this->Produto_model->add_produto($params);
            redirect('produto/index');
        }
        else
        {            
            $data['_view'] = 'produto/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a produto
     */
    function edit($idproduto)
    {   
        // check if the produto exists before trying to edit it
        $data['produto'] = $this->Produto_model->get_produto($idproduto);
        
        if(isset($data['produto']['idproduto']))
        {
            if(isset($_POST) && count($_POST) > 0)     
            {   
                $params = array(
					'nome' => $this->input->post('nome'),
                    'descricao' => $this->input->post('descricao'),
                    'valor' => $this->input->post('valor'),
                    'categoria' => $this->input->post('categoria')
                );

                $this->Produto_model->update_produto($idproduto,$params);            
                redirect('produto/index');
            }
            else
            {
                $data['_view'] = 'produto/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The produto you are trying to edit does not exist.');
    } 

    /*
     * Deleting produto
     */
    function remove($idproduto)
    {
        $produto = $this->Produto_model->get_produto($idproduto);

        // check if the produto exists before trying to delete it
        if(isset($produto['idproduto']))
        {
            $this->Produto_model->delete_produto($idproduto);
            redirect('produto/index');
        }
        else
            show_error('The produto you are trying to delete does not exist.');
    }
    
}
