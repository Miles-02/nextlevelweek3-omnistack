<?php
defined('BASEPATH') or exit('No direct script access allowed');
class ServicoEvento extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Servicoevento_model');
        $this->load->model('Servico_model');
        $this->load->model('Evento_model');
    }
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE;
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;

        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('servicoEvento/index?');
        $config['total_rows'] = $this->ServicoEvento_model->get_all_servicoEvento_count();
        $this->pagination->initialize($config);

        $data['servicoEvento'] = $this->ServicoEvento_model->get_all_servicoEvento($params);

        $data['_view'] = 'servicoEvento/index';
        $this->load->view('layouts/main',$data);
    }
    function add(){
        if (isset($_POST) && count($_POST) > 0) {
            $params = array(
                'evento_idevento' => $this->input->post('evento_idevento'),
                'servico_idservico' => $this->input->post('servico_idservico'),
                'quantidade' => $this->input->post('quantidade'),
            );
            $tiposervico = $this->input->post('servico_idservico');
            $evento_id = $this->input->post('evento_idevento');

            $total_servico = $this->ServicoEvento_model->get_qtd_servicos_por_evento($evento_id, $tiposervico);

            if($total_servico==1){
                redirect('evento/eventoDetalhes/'.$evento_id);
                return;
            }else{
                $servicoEvento_id = $this->ServicoEvento_model->add_servicoEvento($params);
                redirect('evento/eventoDetalhes/'.$evento_id);
            }
        } else {
            $this->load->model('Evento_model');
            $data['all_evento'] = $this->Evento_model->get_all_evento();

            $this->load->model('Servico_model');
            $data['all_servico'] = $this->Servico_model->get_all_servico();

            $data['_view'] = 'servicoEvento/add';
            $this->load->view('layouts/main', $data);
        }
    }
    function edit($idservicoEvento){

        $data['servicoEvento'] = $this->ServicoEvento_model->get_servicoEvento($idservicoEvento);
        $evento_id = $this->ServicoEvento_model->get_evento_por_servico($idservicoEvento);

        if(isset($data['servicoEvento']['idservicoEvento']))
        {
            if(isset($_POST) && count($_POST) > 0)
            {
                $params = array(
                    'quantidade' => $this->input->post('quantidade'),
                );
                $this->ServicoEvento_model->update_servicoEvento($idservicoEvento,$params);
                redirect('evento/eventoDetalhes/'.$evento_id);
            }
            else
            {
                $data['_view'] = 'servicoEvento/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The gerente you are trying to edit does not exist.');
    }
    function remove($idservicoEvento)
    {
        $servicoEvento = $this->ServicoEvento_model->get_servicoEvento($idservicoEvento);

        // check if the tipousuario exists before trying to delete it
        if(isset($servicoEvento['idservicoEvento']))
        {
            $this->ServicoEvento_model->delete_servicoEvento($idservicoEvento);
            redirect('servicoEvento/index');
        }
        else
            show_error('The tipousuario you are trying to delete does not exist.');
    }
}
