<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Evento extends CI_Controller{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Servicoevento_model');
        $this->load->model('Servico_model');
        $this->load->model('Evento_model');
        $this->load->model('Empresa_model');
        $this->load->model('Caixa_model');
        $this->load->model('Comanda_model');
        $this->load->model('Venda_model');
    }
    function index()
    {
        $usuario = $this->session->userdata('logged_in');
        $params['limit'] = RECORDS_PER_PAGE;
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;

        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('evento/index?');
        $config['total_rows'] = $this->Evento_model->get_all_evento_count();
        $this->pagination->initialize($config);

        $data['evento'] = $this->Evento_model->get_all_evento($params);
        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];

        $data['_view'] = 'evento/index';
        $this->load->view('layouts/main',$data);
    }

    function add()
    {
        if(isset($_POST) && count($_POST) > 0)
        {
            $params = array(
                'titulo' => $this->input->post('titulo'),
                'descricao' => $this->input->post('descricao'),
                'data' => $this->input->post('data'),
                'artista' => $this->input->post('artista'),
                'empresa_idempresa' => 1,
                'status' => 0,
            );

            $evento_id = $this->Evento_model->add_evento($params);

            // $servico = array(
            //     'quantidade' => $this->input->post('quantidade'),
            //     'servico_idservico' => $this->input->post('servico_idservico'),
            //     'evento_idevento' => $evento_id,
            // );
            // $servico_id = $this->Servicoevento_model->add_servicoevento($servico);

            $caixa = array(
                'valor_inicial' => 0,
                'valor_final' => 0,
                'status' => 0,
                'funcionario_idfuncionario' => 1,
                'evento_idevento' => $evento_id,
            );

            $caixa_id = $this->Caixa_model->add_caixa($caixa);

            $data['evento'] = $this->Evento_model->get_evento($evento_id);
            $data['_view'] = 'evento/eventoDetalhes';
            $this->load->view('layouts/main',$data);

        }
        else
        {
            $this->load->model('Servico_model');
            $data['all_servico'] = $this->Servico_model->get_all_servico();

            $data['_view'] = 'evento/add';
            $this->load->view('layouts/main',$data);
        }
    }

    function abrir($idevento){
        $usuario = $this->session->userdata('logged_in');
        $data['evento'] = $this->Evento_model->get_evento($idevento);

        $evento_aberto = $this->Evento_model->get_evento_aberto_empresa($usuario['empresa']);
        if($evento_aberto>0){
            $msg = 'Já existe um evento aberto.';
            redirect('evento/index', 'refresh');
        }else{
            if(isset($data['evento']['idevento']))
            {
                $params = array(
                    'status' => 1,
                );

                $this->Evento_model->update_evento($idevento,$params);
                redirect('evento/index');
            }
            else
                show_error('The evento you are trying to edit does not exist.');
        }

    }

    function fechar($idevento){
        // check if the empresa exists before trying to edit it
        $data['evento'] = $this->Evento_model->get_evento($idevento);

        $data['comandas'] = $this->Comanda_model->get_all_comanda();

        foreach($data['comandas'] as $comanda){
            if($comanda['status'] === 1){
                show_error('Ainda existem comandas abertas no evento!');
            }
        }


        if(isset($data['evento']['idevento']))
        {
            $params = array(
                'status' => 0,
            );

            $this->Evento_model->update_evento($idevento,$params);
            redirect('evento/index');
        }
        else
            show_error('The evento you are trying to edit does not exist.');
    }

    function acompanhamento($idevento){
        $usuario = $this->session->userdata('logged_in');

        $consumo = $this->Venda_model->get_total_consumo($idevento);
        foreach ($consumo as $cons) {
            $total_consumo = $cons['total_consumo'];
        }
        $servico = $this->Venda_model->get_total_servico($idevento);
        foreach ($servico as $serv) {
            $total_servico = $serv['total_servico'];
        }
        $vendas = $this->Venda_model->get_total_vendas($idevento);
        foreach ($vendas as $ven) {
            $total_vendas = $ven['total_vendas'];
        }
        $data['total_clientes'] = $this->Comanda_model->get_count_comanda_evento($idevento);
        $data['total_vendas'] = $total_vendas;
        $data['total_consumo'] = $total_consumo;
        $data['total_servico'] = $total_servico;
        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];
        $data['comanda'] = $this->Comanda_model->get_all_comanda();

        $data['_view'] = 'evento/acompanhamento';
        $this->load->view('layouts/main',$data);
    }

    function edit(){


        $this->load->view('evento/add');
        
    }


}