<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Cliente extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Cliente_model');
        $this->load->model('Endereco_model');
        $this->load->model('Pessoa_model');
    } 


    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('cliente/index?');
        $config['total_rows'] = $this->Cliente_model->get_all_cliente_count();
        $this->pagination->initialize($config);

        $data['cliente'] = $this->Cliente_model->get_all_cliente($params);
        
        $data['_view'] = 'cliente/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new cliente
     */
    function add()
    {
        $this->load->library('form_validation');

        if(isset($_POST) && count($_POST) > 0) {
            $endereco = array(
                'rua' => $this->input->post('rua'),
                'numero' => $this->input->post('numero'),
                'cep' => $this->input->post('cep'),
                'cidade' => $this->input->post('cidade'),
                'bairro' => $this->input->post('bairro'),
                'estado' => $this->input->post('estado'),
            );
            $endereco_id = $this->Endereco_model->add_endereco($endereco);

            $pessoa = array(
                'primeiro_nome' => $this->input->post('primeiro_nome'),
                'sobrenome' => $this->input->post('sobrenome'),
                'nasc' => $this->input->post('nasc'),
                'cpf' => $this->input->post('cpf'),
                'email' => $this->input->post('email'),
                'senha' => $this->input->post('senha'),
                'sexo' => $this->input->post('sexo'),
                'endereco_idendereco' => $endereco_id,
            );

            $pessoa_id = $this->Pessoa_model->add_pessoa($pessoa);

            $cliente = array(
                'cpf' => $this->input->post('cpf'),
                'senha' => $this->input->post('senha'),
                'pessoa_idpessoa' => $pessoa_id,

            );

            $cliente_id = $this->Cliente_model->add_cliente($cliente);
            redirect('cliente/index');

        }else{
            $data['_view'] = 'cliente/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a cliente
     */
    function edit($idcliente)
    {   
        // check if the cliente exists before trying to edit it
        $data['cliente'] = $this->Cliente_model->get_cliente($idcliente);
        
        if(isset($data['cliente']['idcliente']))
        {
            if(isset($_POST) && count($_POST) > 0)     
            {   
                $params = array(
					'cpf' => $this->input->post('cpf'),
					'senha' => $this->input->post('senha'),
					'pessoa_idpessoa' => $this->input->post('pessoa_idpessoa'),
                );

                $this->Cliente_model->update_cliente($idcliente,$params);            
                redirect('cliente/index');
            }
            else
            {
                $data['_view'] = 'cliente/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cliente you are trying to edit does not exist.');
    } 

    /*
     * Deleting cliente
     */
    function remove($idcliente)
    {
        $cliente = $this->Cliente_model->get_cliente($idcliente);

        // check if the cliente exists before trying to delete it
        if(isset($cliente['idcliente']))
        {
            $this->Cliente_model->delete_cliente($idcliente);
            redirect('cliente/index');
        }
        else
            show_error('The cliente you are trying to delete does not exist.');
    }
    
}
