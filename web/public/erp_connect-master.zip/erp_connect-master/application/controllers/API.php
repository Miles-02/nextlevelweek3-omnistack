<?php

require_once APPPATH . 'libraries/API_Controller.php';

class API extends API_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model('Funcionario_model');
        $this->load->model('Comanda_model');
        $this->load->model('Evento_model');
        $this->load->model('Cartao_model');

    }

    public function get_comanda()
    {
        header("Access-Control-Allow-Origin: *");
        header("Content-type: application/json");

        $this->_apiConfig([
            'methods' => ['GET'], // 'GET', 'OPTIONS'
        ]);

        $idfuncionario = $_GET['idfuncionario'];
        $idcartao = $_GET['idcartao'];

        $funcionario = $this->Funcionario_model->get_funcionario_api($idfuncionario);
        foreach ($funcionario as $fun){
            $empresa_idempresa = $fun['empresa_idempresa'];
        }
        $evento = $this->Evento_model->get_evento_aberto_empresa($empresa_idempresa);
        foreach ($evento as $ev){
            $idevento = $ev['idevento'];
        }
        $cartao = $this->Cartao_model->get_cartao($idcartao);
        $comanda = $this->Comanda_model->get_comanda_cartao($idcartao, $idevento);

        if((isset($funcionario)) && (!empty($funcionario))){
            if (!empty($cartao)){
                if(!empty($comanda)){
                    $this->api_return(
                        [
                            "result" => [
                                $comanda
                            ],
                        ],
                        200);
                }else{
                    $this->api_return(
                        [
                            'erro' => 'Não existe comanda'
                        ],
                        200);
                }
            }else{
                $this->api_return(
                    [
                        'erro' => 'Cartão inválido'
                    ],
                    200);
            }
        }else{
            $this->api_return(
                [
                    'erro' => 'Funcionário não registrado'
                ],
                200);
        }
    }

}