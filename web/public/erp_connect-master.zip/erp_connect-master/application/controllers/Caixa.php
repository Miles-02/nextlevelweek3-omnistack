<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Caixa extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Caixa_model');
    }

    function index()
    {
        $usuario = $this->session->userdata('logged_in');
        $params['limit'] = RECORDS_PER_PAGE;
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;

        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('caixa/index?');
        $config['total_rows'] = $this->Caixa_model->get_all_caixa_count();
        $this->pagination->initialize($config);

        $data['caixa'] = $this->Caixa_model->get_all_caixa($params);

        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];

        $data['_view'] = 'caixa/index';
        $this->load->view('layouts/main',$data);
    }

    function add()
    {
        if(isset($_POST) && count($_POST) > 0)
        {
            $params = array(
                'valor' => $this->input->post('valor'),
                'status' => 1,
                'evento_idevento' => $this->input->post('evento_idevento'),
                'funcionario_idfuncionario' => 1,/*pegar funcionario da sessao*/
            );

            $evento_id = $this->input->post('evento_idevento');
            $total_caixa = $this->Caixa_model->get_registros_caixa($evento_id);
            if($total_caixa==1){
                $data['msg'] = 'Caixa do evento já está aberto';
                $data['_view'] = 'dashboard';
                $this->load->view('layouts/main',$data);
            }else{
                $caixa_id = $this->Caixa_model->add_caixa($params);
                $data['msg'] = 'Caixa aberto com sucesso';
                $data['_view'] = 'dashboard';
                $this->load->view('layouts/main',$data);
            }
        }
        else
        {
            $data['msg'] = 'Erro ao abrir caixa, tente novamente';
            $data['_view'] = 'dashboard';
            $this->load->view('layouts/main',$data);
        }
    }

    function edit($idcaixa)
    {
        // check if the caixa exists before trying to edit it
        $data['caixa'] = $this->Caixa_model->get_caixa($idcaixa);

        if(isset($data['caixa']['idcaixa']))
        {
            if(isset($_POST) && count($_POST) > 0)
            {
                $params = array(
                    'valor' => $this->input->post('valor'),
                    'status' => $this->input->post('status'),
                    'evento_idevento' => $this->input->post('evento_idevento'),
                    'funcionario_idfuncionario' => $this->input->post('funcionario_idfuncionario'),
                );

                $this->Caixa_model->update_caixa($idcaixa,$params);
                redirect('caixa/index');
            }
            else
            {
                $data['_view'] = 'caixa/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The caixa you are trying to edit does not exist.');
    }
    function fechar($idcaixa){

        $data['caixa'] = $this->Caixa_model->get_caixa($idcaixa);

        if(isset($data['caixa']['idcaixa']))
        {
            $params = array(
                'status' => 0,
            );

            $this->Caixa_model->update_caixa($idcaixa,$params);
            redirect('cartaoEvento/index');
        }
        else
            show_error('The caixa you are trying to edit does not exist.');
    }
    function faturamento_evento(){

    }
}
