<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Tipo_pagamento extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Tipo_pagamento_model');
    }

    function index()
    {
        $usuario = $this->session->userdata('logged_in');
        $data['tipopagamento'] = $this->Tipo_pagamento_model->get_all_tipo_pagamento();

        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];
        $data['_view'] = 'pagamento/index';
        $this->load->view('layouts/main',$data);
    }

    function add()
    {
        $usuario = $this->session->userdata('logged_in');
        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];

        if(isset($_POST) && count($_POST) > 0)
        {
            $params = array(
                'nome' => $this->input->post('nome'),
                'status' => 1,
            );

            $tipo_pagamento_id = $this->Tipo_pagamento_model->add_tipo_pagamento($params);
            redirect('tipo_pagamento/index');
        }
        else
        {
            $data['_view'] = 'pagamento/add';
            $this->load->view('layouts/main',$data);
        }
    }

    function habilitar_pagamento($idtipopagamento){

        $data['tipo_pagamento'] = $this->Tipo_pagamento_model->get_tipo_pagamento($idtipopagamento);
        if(isset($data['tipo_pagamento']['idtipo_pagamento']))
        {
            $params = array(
                'status' => 1,
            );

            $this->Tipo_pagamento_model->update_tipo_pagamento($idtipopagamento,$params);
            redirect('tipo_pagamento/index');
        }
        else
            show_error('The pagamento you are trying to edit does not exist.');
    }
    function desabilitar_pagamento($idtipopagamento){

        $data['tipo_pagamento'] = $this->Tipo_pagamento_model->get_tipo_pagamento($idtipopagamento);
        if(isset($data['tipo_pagamento']['idtipo_pagamento']))
        {
            $params = array(
                'status' => 0,
            );

            $this->Tipo_pagamento_model->update_tipo_pagamento($idtipopagamento,$params);
            redirect('tipo_pagamento/index');
        }
        else
            show_error('The evento you are trying to edit does not exist.');
    }
}