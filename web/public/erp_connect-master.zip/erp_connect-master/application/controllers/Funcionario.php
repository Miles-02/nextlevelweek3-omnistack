<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Funcionario extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Funcionario_model');
        $this->load->model('Endereco_model');
        $this->load->model('Empresa_model');
    } 

    function index()
    {
        $usuario = $this->session->userdata('logged_in');
        $idempresa = $usuario['empresa'];

        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('funcionario/index?');
        $config['total_rows'] = $this->Funcionario_model->get_funcionario_empresa_count($idempresa);
        $this->pagination->initialize($config);

        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];
        $data['funcionario'] = $this->Funcionario_model->get_funcionario_empresa($params, $idempresa);
        $data['_view'] = 'funcionario/index';
        $this->load->view('layouts/main',$data);
    }

    function add()
    {
        $usuario = $this->session->userdata('logged_in');
        $idempresa = $usuario['empresa'];

        if(isset($_POST) && count($_POST) > 0)
        {
            $funcionario = array(
                'nome' => $this->input->post('nome'),
                'codigo' => $this->input->post('codigo'),
                'senha' => $this->input->post('senha'),
                'gerente' => 0,
                'administrativo' => 0,
                'empresa_idempresa' => $idempresa,
            );
            $funcionario_id = $this->Funcionario_model->add_funcionario($funcionario);
            redirect('funcionario/index');
        }
        else
        {
            $data['nome_funcionario'] = $usuario['nome'];
            $data['gerente'] = $usuario['gerente'];
            $data['_view'] = 'funcionario/add';
            $this->load->view('layouts/main',$data);
        }
    }

    function edit($idfuncionario)
    {
        $data['funcionario'] = $this->Funcionario_model->get_funcionario($idfuncionario);
        
        if(isset($data['funcionario']['idfuncionario']))
        {
            if(isset($_POST) && count($_POST) > 0)     
            {   
                $params = array(
					'codigo' => $this->input->post('codigo'),
					'senha' => $this->input->post('senha'),
					'empresa_idempresa' => $this->input->post('empresa_idempresa'),
					'pessoa_idpessoa' => $this->input->post('pessoa_idpessoa'),
                );

                $this->Funcionario_model->update_funcionario($idfuncionario,$params);            
                redirect('funcionario/index');
            }
            else
            {
                $data['_view'] = 'funcionario/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The funcionario you are trying to edit does not exist.');
    } 

    function remove($idfuncionario)
    {
        $funcionario = $this->Funcionario_model->get_funcionario($idfuncionario);

        // check if the funcionario exists before trying to delete it
        if(isset($funcionario['idfuncionario']))
        {
            $this->Funcionario_model->delete_funcionario($idfuncionario);
            redirect('funcionario/index');
        }
        else
            show_error('The funcionario you are trying to delete does not exist.');
    }

    function adicionar_gerente($idfuncionario){
        $data['funcionario'] = $this->Funcionario_model->get_funcionario($idfuncionario);

        if (isset($data['funcionario']['idfuncionario'])) {
            $params = array(
                'gerente' => 1,
            );

            $this->Funcionario_model->update_funcionario($idfuncionario, $params);
            redirect('funcionario/index');
        } else {
            show_error('The funcionario you are trying to edit does not exist.');
        }
    }

    function remover_gerente($idfuncionario)
    {
        $data['funcionario'] = $this->Funcionario_model->get_funcionario($idfuncionario);

        if (isset($data['funcionario']['idfuncionario'])) {
            $params = array(
                'gerente' => 0,
            );

            $this->Funcionario_model->update_funcionario($idfuncionario, $params);
            redirect('funcionario/index');
        } else {
            show_error('The funcionario you are trying to edit does not exist.');
        }
    }
}
