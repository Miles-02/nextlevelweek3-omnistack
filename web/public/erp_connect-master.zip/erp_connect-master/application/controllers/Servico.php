<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Servico extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Servico_model');
    }

    function index()
    {
        $usuario = $this->session->userdata('logged_in');
        $params['limit'] = RECORDS_PER_PAGE;
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;

        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('servico/index?');
        $config['total_rows'] = $this->Servico_model->get_all_servico_count();
        $this->pagination->initialize($config);

        $data['servico'] = $this->Servico_model->get_all_servico($params);

        $data['nome_funcionario'] = $usuario['nome'];
        $data['gerente'] = $usuario['gerente'];
        $data['_view'] = 'servico/index';
        $this->load->view('layouts/main',$data);
    }

    function add()
    {
        if(isset($_POST) && count($_POST) > 0)
        {
            $params = array(
                'nome' => $this->input->post('nome'),
                'entrada' => $this->input->post('entrada'),
                'consumacao' => $this->input->post('consumacao'),
            );

            $servico_id = $this->Servico_model->add_servico($params);
            redirect('servico/index');
        }
        else
        {
            $data['_view'] = 'servico/add';
            $this->load->view('layouts/main',$data);
        }
    }


}