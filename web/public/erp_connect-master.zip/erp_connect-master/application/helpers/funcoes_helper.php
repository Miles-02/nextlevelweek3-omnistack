<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); // linha de proteção ao controller

function security($senha)
{
    return hash("sha256", hash("sha256", hash("sha256", $senha)));
}

?>