<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Inserir Produto</h3>
            </div>
            <?php echo form_open('produto/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-3">
						<label for="nome" class="control-label">Nome</label>
						<div class="form-group">
							<input type="text" name="nome" value="<?php echo $this->input->post('nome'); ?>" class="form-control" id="nome" />
						</div>
					</div>
					<div class="col-md-3">
						<label for="descricao" class="control-label">Descrição</label>
						<div class="form-group">
							<input type="text" name="descricao" value="<?php echo $this->input->post('descricao'); ?>" class="form-control" id="descricao" />
						</div>
					</div>
                    <div class="col-md-3">
                        <label for="categoria" class="control-label">Categoria</label>
                        <div class="form-group">
                            <input type="text" name="categoria" value="<?php echo $this->input->post('categoria'); ?>" class="form-control" id="categoria" />
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="valor" class="control-label">Valor</label>
                        <div class="form-group">
                            <input type="text" name="valor" value="<?php echo $this->input->post('valor'); ?>" class="form-control" id="valor" />
                        </div>
                    </div>

					<div class="col-md-3">
                        <label for="img" class="control-label">Imagem</label>
                        <div class="form-group">
                            <input type="file" name="img" value="<?php echo $this->input->post('img'); ?>" class="form-control" id="img" />
                        </div>
                    </div>
				</div>
			</div>
          	<div class="box-footer text-right">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Salvar
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>