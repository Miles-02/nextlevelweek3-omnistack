<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Comandas</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('comanda/add'); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span></a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Data</th>
						<th>Produtos</th>
                        <th>Quantidade</th>
						<th>Total</th>
						<th>Cliente</th>
                        <th>Status</th>
						<th>Ações</th>
                    </tr>
                    <?php foreach($comanda as $c){ ?>
                    <tr>
						<td><?php echo $c['data']; ?></td>
						<td><?php echo $c['produto']; ?></td>
						<td><?php echo $c['quantidade']; ?></td>
						<td><?php echo $c['total']; ?></td>
						<td><?php echo $c['nome']; ?></td>
                        <td><?php if($c['status']==0){ echo 'Fechada';}else if($c['status']==1){echo 'Aberta';}else{echo 'Estornada';}; ?></td>
						<td>
                            <a href="<?php echo site_url('comanda/estornar/'.$c['idcomanda']); ?>" class="btn btn-info btn-xs"> Estornar</a>
                            <a href="<?php echo site_url('comanda/remove/'.$c['idcomanda']); ?>" class="btn btn-danger btn-xs"> Cancelar</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
