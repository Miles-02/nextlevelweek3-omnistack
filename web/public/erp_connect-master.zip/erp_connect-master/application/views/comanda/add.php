<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Registrar comanda</h3>
            </div>
            <?php echo form_open('comanda/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-3">
						<label for="data" class="control-label">Data</label>
						<div class="form-group">
							<input type="date" name="data" value="<?php echo $this->input->post('data'); ?>" class="form-control" id="data" />
						</div>
					</div>
                    <div class="col-md-3">
                        <label for="produto_idproduto" class="control-label">Produto</label>
                        <select name="produto_idproduto" class="form-control">
                            <option value="">Selecione</option>
                            <?php
                            foreach($all_produto as $produto)
                            {
                                $selected = ($produto['idproduto'] == $this->input->post('produto_idproduto')) ? ' selected="selected"' : "";

                                echo '<option value="'.$produto['idproduto'].'" '.$selected.'>'.$produto['nome'].'</option>';
                            }
                            ?>
                        </select>
                    </div>
					<div class="col-md-2">
						<label for="quantidade" class="control-label">Quantidade</label>
						<div class="form-group">
							<input type="text" name="quantidade" value="<?php echo $this->input->post('quantidade'); ?>" class="form-control" id="quantidade" />
						</div>
					</div>
					<div class="col-md-2">
						<label for="total" class="control-label">Total</label>
						<div class="form-group">
							<input type="text" name="total" value="<?php echo $this->input->post('total');  ?>" class="form-control" id="total"  />
						</div>
					</div>

					<div class="col-md-2">
						<label for="cartao_idcartao" class="control-label">Cartao Idcartao</label>
						<div class="form-group">
							<input type="text" name="cartao_idcartao" value="<?php echo $this->input->post('cartao_idcartao'); ?>" class="form-control" id="cartao_idcartao" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer text-right">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Salvar
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>