<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Comanda Edit</h3>
            </div>
			<?php echo form_open('comanda/edit/'.$comanda['idcomanda']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="data" class="control-label">Data</label>
						<div class="form-group">
							<input type="text" name="data" value="<?php echo ($this->input->post('data') ? $this->input->post('data') : $comanda['data']); ?>" class="has-datepicker form-control" id="data" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="status" class="control-label">Status</label>
						<div class="form-group">
							<input type="text" name="status" value="<?php echo ($this->input->post('status') ? $this->input->post('status') : $comanda['status']); ?>" class="form-control" id="status" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="total" class="control-label">Total</label>
						<div class="form-group">
							<input type="text" name="total" value="<?php echo ($this->input->post('total') ? $this->input->post('total') : $comanda['total']); ?>" class="form-control" id="total" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="produto_idproduto" class="control-label">Produto Idproduto</label>
						<div class="form-group">
							<input type="text" name="produto_idproduto" value="<?php echo ($this->input->post('produto_idproduto') ? $this->input->post('produto_idproduto') : $comanda['produto_idproduto']); ?>" class="form-control" id="produto_idproduto" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="cartao_idcartao" class="control-label">Cartao Idcartao</label>
						<div class="form-group">
							<input type="text" name="cartao_idcartao" value="<?php echo ($this->input->post('cartao_idcartao') ? $this->input->post('cartao_idcartao') : $comanda['cartao_idcartao']); ?>" class="form-control" id="cartao_idcartao" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="funcionario_idfuncionario" class="control-label">Funcionario Idfuncionario</label>
						<div class="form-group">
							<input type="text" name="funcionario_idfuncionario" value="<?php echo ($this->input->post('funcionario_idfuncionario') ? $this->input->post('funcionario_idfuncionario') : $comanda['funcionario_idfuncionario']); ?>" class="form-control" id="funcionario_idfuncionario" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>