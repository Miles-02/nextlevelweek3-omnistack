<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Cartões cadastrados</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('cartao/add'); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span></a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Número do cartão</th>
						<th>Saldo</th>
						<th>Cliente</th>
                        <th>Status</th>
						<th>Ações</th>
                    </tr>
                    <?php foreach($cartao as $c){ ?>
                    <tr>
						<td><?php echo $c['registro']; ?></td>
						<td>R$ <?php echo $c['saldo']; ?></td>
						<td><?php echo $c['pessoa']; ?></td>
                        <td><?php if($c['status']==0){ echo 'Desativado';}else{echo 'Ativo';}; ?></td>
						<td>
                            <a href="<?php echo site_url('cartao/remove/'.$c['idcartao']); ?>" class="btn btn-danger btn-xs"> Desativar cartão</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
