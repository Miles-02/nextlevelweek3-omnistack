<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Cartao Edit</h3>
            </div>
			<?php echo form_open('cartao/edit/'.$cartao['idcartao']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="registro" class="control-label">Registro</label>
						<div class="form-group">
							<input type="text" name="registro" value="<?php echo ($this->input->post('registro') ? $this->input->post('registro') : $cartao['registro']); ?>" class="form-control" id="registro" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="saldo" class="control-label">Saldo</label>
						<div class="form-group">
							<input type="text" name="saldo" value="<?php echo ($this->input->post('saldo') ? $this->input->post('saldo') : $cartao['saldo']); ?>" class="form-control" id="saldo" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="cliente_idcliente" class="control-label">Cliente Idcliente</label>
						<div class="form-group">
							<input type="text" name="cliente_idcliente" value="<?php echo ($this->input->post('cliente_idcliente') ? $this->input->post('cliente_idcliente') : $cartao['cliente_idcliente']); ?>" class="form-control" id="cliente_idcliente" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>