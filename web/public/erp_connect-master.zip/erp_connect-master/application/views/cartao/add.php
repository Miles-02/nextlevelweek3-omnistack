<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <p class="text-center"><?php if (isset($msg)) {
                    echo $msg;
                } ?>
            </p>
            <div class="box-header with-border">
              	<h3 class="box-title">Registrar cartão</h3>
            </div>
            <?php echo form_open('cartao/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="registro" class="control-label">Registro</label>
						<div class="form-group">
							<input type="text" name="registro" value="<?php echo $this->input->post('registro'); ?>" class="form-control" id="registro" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="saldo" class="control-label">Saldo</label>
						<div class="form-group">
							<input type="text" name="saldo" value="<?php echo $this->input->post('saldo'); ?>" class="form-control" id="saldo" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="cliente_idcliente" class="control-label">CPF</label>
						<div class="form-group">
							<input type="text" name="cliente_idcliente" value="<?php echo $this->input->post('cliente_idcliente'); ?>" class="form-control" id="cliente_idcliente" placeholder="Buscar cliente" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer text-right">
                <button type="reset" class="btn btn-danger">
                    <i class="fa fa-check"></i> Redefinir
                </button>
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Salvar
                </button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>