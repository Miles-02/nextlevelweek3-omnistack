<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Formas de pagamento</h3>
                <div class="box-tools">
                    <a href="<?php echo site_url('tipo_pagamento/add'); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span></a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                    <?php foreach($tipopagamento as $p){ ?>
                        <tr>
                            <td><?php echo $p['idtipo_pagamento']; ?></td>
                            <td><?php echo $p['nome']; ?></td>
                            <td><?php if($p['status']==0){ echo 'Inativo';}else{echo 'Ativo';}; ?></td>
                            <td>
                                <a href="
                                <?php if($p['status'] ==  0){
                                    echo site_url('tipo_pagamento/habilitar_pagamento/'.$p['idtipo_pagamento']);
                                } else{
                                    echo site_url('tipo_pagamento/desabilitar_pagamento/'.$p['idtipo_pagamento']);

                                }

                                ?>"
                                <?php if($p['status'] == 0){
                                    echo 'class="btn btn-info btn-xs"><span class="fa fa-"></span> ';
                                }
                                else{
                                    echo 'class="btn btn-danger btn-xs"><span class="fa fa-"></span> ';
                                } ?>

                                <?php if($p['status'] == 0){
                                    echo 'Habilitar';
                                } else{
                                    echo 'Desabilitar';
                                }
                                ?>

                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
