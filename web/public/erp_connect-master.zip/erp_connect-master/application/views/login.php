<style>
    #telaLogin{
        width: 400px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        box-shadow: 1px 5px 30px rgb(195, 195, 195);
    }

    body{
        background-image: url(<?php echo site_url('resources/img/fundo.png');?>);
    }

    #imgconnectapp{
        width: 200px;
        margin-left: 25%;
        margin-top: 10px;
    }
</style>

<!-- jQuery 2.2.3 -->
<script src="<?php echo site_url('resources/js/jquery-2.2.3.min.js');?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo site_url('resources/js/bootstrap.min.js');?>"></script>
<!-- Popper -->
<script src="<?php echo site_url('resources/js/popper.js/dist/popper.js');?>"></script>

<link rel="stylesheet" href="<?php echo site_url('resources/css/login/bootstrap.css');?>">

<title>ConnectApp - Login</title>
<body>
<div class="card" id="telaLogin">
    <img class="" id="imgconnectapp"src="<?php echo site_url('resources/img/logoconnect.png');?>" alt="Imagem de capa do card">
    <div class="card-body">
        <?php
        echo form_open('autentica');
        echo validation_errors();
        ?>
        <form>
            <div class="form-group">
                <p class="text-center"><?php if (isset($msg)) {
                        echo $msg;
                    } ?>
                </p>
                <label>Código</label>
                <input type="number" class="form-control" name="codigo" value="<?php echo $this->input->post('codigo'); ?>" id="codigo" placeholder="Insira seu código">
            </div>
            <div class="form-group">
                <label>Senha</label>
                <input type="password" class="form-control" name="senha" value="<?php echo $this->input->post('senha'); ?>" id="senha" placeholder="Insira sua senha">
            </div>
            <button type="submit" class="btn btn-outline-success btn-block">Entrar</button>
        </form>
        <?php echo form_close(); ?>
    </div>
</div>
</body>
