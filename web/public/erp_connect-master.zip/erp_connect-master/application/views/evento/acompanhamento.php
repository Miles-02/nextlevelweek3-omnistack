<link rel="stylesheet" type="text/css" href="<?php echo site_url('resources/css/acompanhamento/estilo.css');?>">
<div class="conteudo">
    <div class="row">
        <div class="col-md-3">
            <div class="card-counter primary">
                <i class="fa fa-ticket"></i>
                <span class="count-numbers">R$ <?php if($total_servico==NULL){echo '0';}else{echo $total_servico; }?></span>
                <span class="count-name">Serviços</span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card-counter danger">
                <i class="fa fa-glass"></i>
                <span class="count-numbers">R$ <?php if($total_consumo==NULL){echo '0';}else{echo $total_consumo; }?></span>
                <span class="count-name">Consumo</span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card-counter success">
                <i class="fa fa-usd"></i>
                <span class="count-numbers">R$ <?php echo $total_vendas?></span>
                <span class="count-name">Faturamento Total</span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card-counter info">
                <i class="fa fa-users"></i>
                <span class="count-numbers"><?php echo $total_clientes ?></span>
                <span class="count-name">Clientes</span>
            </div>
        </div>
    </div>
</div>

