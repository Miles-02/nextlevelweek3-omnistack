<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Eventos</h3>
                <div class="box-tools">
                    <a href="<?php echo site_url('evento/add'); ?>" class="btn btn-success btn-sm">Inserir</a>
                </div>
                <p class="text-center"><?php if (isset($msg)) {
                        echo $msg;
                    } ?>
                </p>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>Data</th>
                        <th>Título</th>
                        <th>Descrição</th>
                        <th>Artista</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                    <?php foreach($evento as $e){ ?>
                        <tr>
                            <td><?php echo $e['data']; ?></td>
                            <td><?php echo $e['titulo']; ?></td>
                            <td><?php echo $e['descricao']; ?></td>
                            <td><?php echo $e['artista']; ?></td>
                            <td><?php if($e['status']==0){ echo 'Fechado';}else{echo 'Aberto';}; ?></td>
                            <td>
                                <a href="
                                <?php if($e['status'] ==  0){
                                    echo site_url('evento/abrir/'.$e['idevento']);
                                    } else{
                                        echo site_url('evento/fechar/'.$e['idevento']);

                                    }

                                ?>"
                                <?php if($e['status'] == 0){
                                    echo 'class="btn btn-info btn-xs"><span class="fa fa-"></span> ';
                                }
                                else{
                                    echo 'class="btn btn-danger btn-xs"><span class="fa fa-"></span> ';
                                } ?>

                                <?php if($e['status'] == 0){
                                    echo 'Abrir';
                                } else{
                                    echo 'Fechar';
                                } 
                                ?>
                                
                                </a>
                                <a href="<?php echo site_url('evento/acompanhamento/'.$e['idevento']); ?>" class="btn btn-success btn-xs"><span class="fa fa-"></span> Acompanhamento</a>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
