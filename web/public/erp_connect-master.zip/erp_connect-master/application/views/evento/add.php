<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">Informações do evento</h3>
            </div>
            <?php echo form_open('evento/add'); ?>
            <div class="box-body">
                <div class="row clearfix">
                    <div class="col-md-4">
                        <label for="titulo" class="control-label">Título</label>
                        <div class="form-group">
                            <input type="text" name="titulo" value="<?php echo $this->input->post('titulo'); ?>" class="form-control" id="titulo" />
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="data" class="control-label">Data</label>
                        <div class="form-group">
                            <input type="date" name="data" value="<?php echo $this->input->post('data'); ?>" class="form-control" id="data" />
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label for="data" class="control-label">Artista</label>
                        <div class="form-group">
                            <input type="text" name="artista" value="<?php echo $this->input->post('artista'); ?>" class="form-control" id="artista" />
                        </div>
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-md-4">
                        <label for="descricao" class="control-label">Descrição</label>
                        <div class="form-group">
                            <input type="text" name="descricao" value="<?php echo $this->input->post('descricao'); ?>" class="form-control" id="descricao" />
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="foto" class="control-label">Foto</label>
                        <div class="form-group">
                            <input type="file" name="foto" value="<?php echo $this->input->post('foto'); ?>" class="form-control" id="foto" />
                        </div>
                    </div>
                </div>
                <!-- <?php
                    $this->load->view('servicoEvento/add');
                ?> -->
            </div>
            <div class="box-footer text-right">
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Salvar
                </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>