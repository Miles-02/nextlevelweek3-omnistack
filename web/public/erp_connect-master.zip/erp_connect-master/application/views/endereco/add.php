<div class="box-header">
    <h3 class="box-title text center">Informações de endereço</h3><hr align="left">
</div>
<div class="box-body">
    <div class="row clearfix">
        <div class="col-md-6">
            <label for="rua" class="control-label">Rua</label>
            <div class="form-group">
                <input type="text" name="rua" value="<?php echo $this->input->post('rua'); ?>" class="form-control" id="rua" />
            </div>
        </div>
        <div class="col-md-3">
            <label for="numero" class="control-label">Número</label>
            <div class="form-group">
                <input type="text" name="numero" value="<?php echo $this->input->post('numero'); ?>" class="form-control" id="numero" />
            </div>
        </div>
        <div class="col-md-3">
            <label for="bairro" class="control-label">Bairro</label>
            <div class="form-group">
                <input type="text" name="bairro" value="<?php echo $this->input->post('bairro'); ?>" class="form-control" id="bairro" />
            </div>
        </div>
        <div class="col-md-4">
            <label for="cidade" class="control-label">Cidade</label>
            <div class="form-group">
                <input type="text" name="cidade" value="<?php echo $this->input->post('cidade'); ?>" class="form-control" id="cidade" />
            </div>
        </div>
        <div class="col-md-4">
            <label for="estado" class="control-label">Estado</label>
            <div class="form-group">
                <input type="text" name="estado" value="<?php echo $this->input->post('estado'); ?>" class="form-control" id="estado" />
            </div>
        </div>
        <div class="col-md-4">
            <label for="cep" class="control-label">CEP</label>
            <div class="form-group">
                <input type="text" name="cep" value="<?php echo $this->input->post('cep'); ?>" class="form-control" id="cep" />
            </div>
        </div>
    </div>
</div>