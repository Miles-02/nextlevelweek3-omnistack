<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">Serviço Add</h3>
            </div>
            <?php echo form_open('servico/add'); ?>
            <div class="box-body">
                <div class="row clearfix">
                    <div class="col-md-4">
                        <label for="tipo" class="control-label">Nome do serviço</label>
                        <div class="form-group">
                            <input type="text" name="nome" value="<?php echo $this->input->post('nome'); ?>" class="form-control" id="nome" />
                        </div>
                    </div>
                   
                    

                    <div class="col-md-4">
                        <label for="entrada" class="control-label">Entrada</label>
                        <div class="form-group">
                            <input type="text" name="entrada" value="<?php echo $this->input->post('entrada'); ?>" class="form-control" id="entrada" />
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="consumacao" class="control-label">Consumação</label>
                        <div class="form-group">
                            <input type="text" name="consumacao" value="<?php echo $this->input->post('consumacao'); ?>" class="form-control" id="consumacao" />
                        </div>
                    </div>

                </div>
            </div>
            <div class="box-footer text-right">
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Salvar
                </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>