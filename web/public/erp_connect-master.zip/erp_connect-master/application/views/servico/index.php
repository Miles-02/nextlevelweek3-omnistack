<style>
.vertical-alignment-helper {
    display:table;
    height: 100%;
    width: 100%;
}
.vertical-align-center {
    
    display: table-cell;
    vertical-align: middle;
}
.modal-content {
    width: 70vw;
    height:inherit;

    margin: 0 auto;
}
</style>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Serviços disponíveis</h3>
                <div class="box-tools">
                    <a class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal">Inserir</a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>Tipo de serviço</th>
                        <th>Entrada</th>
                        <th>Consumação</th>
                    </tr>
                    <?php foreach($servico as $s){ ?>
                        <tr>
                            <td><?php echo $s['nome']; ?></td>
                            <td>R$ <?php echo $s['entrada']; ?></td>
                            <td>R$ <?php echo $s['consumacao']; ?></td>
                        </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
            </div>
        </div>

       
        <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="vertical-alignment-helper">
        <div class="modal-dialog vertical-align-center">
            <div class="modal-content">
            <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Serviço Add</h3>
                    </div>
                    <?php echo form_open('servico/add'); ?>
                    <div class="box-body">
                        <div class="row clearfix">
                            <div class="col-md-4">
                                <label for="nome" class="control-label">Nome do serviço</label>
                                <div class="form-group">
                                    <input type="text" name="nome" value="<?php echo $this->input->post('nome'); ?>" class="form-control" id="nome" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="entrada" class="control-label">Entrada</label>
                                <div class="form-group">
                                    <input type="text" name="entrada" value="<?php echo $this->input->post('entrada'); ?>" class="form-control" id="entrada" />
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="consumacao" class="control-label">Consumação</label>
                                <div class="form-group">
                                    <input type="text" name="consumacao" value="<?php echo $this->input->post('consumacao'); ?>" class="form-control" id="consumacao" />
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="box-footer text-right">
                        <button type="submit" class="btn btn-success">
                            <i class="fa fa-check"></i> Salvar
                        </button>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
            </div>
            </div>
        </div>
    </div>
</div>
       
    </div>


    
</div>



