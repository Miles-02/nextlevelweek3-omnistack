<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Listagem de estoque</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('estoque/add'); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span></a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>Produto</th>
                        <th>Quantidade</th>
						<th>Ações</th>
                    </tr>
                    <?php foreach($estoque as $e){ ?>
                    <tr>
						<td><?php echo $e['produto']; ?></td>
						<td><?php echo $e['quantidade']; ?></td>
						<td>
                            <a href="<?php echo site_url('estoque/edit/'.$e['idestoque']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Alterar</a>
                            <a href="<?php echo site_url('estoque/remove/'.$e['idestoque']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Excluir</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
