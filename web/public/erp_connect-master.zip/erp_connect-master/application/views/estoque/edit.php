<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Estoque Edit</h3>
            </div>
			<?php echo form_open('estoque/edit/'.$estoque['idestoque']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="quantidade" class="control-label">Quantidade</label>
						<div class="form-group">
							<input type="text" name="quantidade" value="<?php echo ($this->input->post('quantidade') ? $this->input->post('quantidade') : $estoque['quantidade']); ?>" class="form-control" id="quantidade" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="produto_idproduto" class="control-label">Produto Idproduto</label>
						<div class="form-group">
							<input type="text" name="produto_idproduto" value="<?php echo ($this->input->post('produto_idproduto') ? $this->input->post('produto_idproduto') : $estoque['produto_idproduto']); ?>" class="form-control" id="produto_idproduto" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>