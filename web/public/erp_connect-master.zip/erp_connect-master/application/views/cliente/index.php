<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Clientes</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('cliente/add'); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span></a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>Nome</th>
						<th>CPF</th>
						<th>Sexo</th>

						<th>Ações</th>
                    </tr>
                    <?php foreach($cliente as $c){ ?>
                    <tr>
						<td><?php echo $c['nome']; ?></td>
						<td><?php echo $c['cpf']; ?></td>
						<td><?php echo $c['sexo']; ?></td>
						<td>
                            <a href="<?php echo site_url('cliente/edit/'.$c['idcliente']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Editar</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
