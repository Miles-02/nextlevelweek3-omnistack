
<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="titulo text center"><strong>Cadastro de Clientes</strong></h3><br>
            </div>
            <?php echo form_open('cliente/add'); ?>
                <?php
                $this->load->view('pessoa/add');
                ?>
            <div class="box-footer text-right">
                <button type="reset" class="btn btn-danger">
                    <i class="fa fa-check"></i> Redefinir
                </button>
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Salvar
                </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>