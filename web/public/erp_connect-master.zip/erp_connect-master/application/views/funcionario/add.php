<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="titulo text center"><strong>Cadastro de Funcionários</strong></h3><br>
            </div>
            <?php echo form_open('funcionario/add'); ?>
            <div class="box-body">
                <div class="row clearfix">
                    <div class="col-md-6">
                        <label for="nome" class="control-label">Nome</label>
                        <div class="form-group">
                            <input type="text" name="nome" value="<?php echo $this->input->post('nome'); ?>" class="form-control" id="nome" />
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label for="codigo" class="control-label">Código</label>
                        <div class="form-group">
                            <input type="text" name="codigo" value="<?php echo $this->input->post('codigo'); ?>" class="form-control" id="codigo" />
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label for="senha" class="control-label">Senha</label>
                        <div class="form-group">
                            <input type="password" name="senha" value="<?php echo $this->input->post('senha'); ?>" class="form-control" id="senha" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer text-right">
                <button type="reset" class="btn btn-danger">
                    <i class="fa fa-check"></i> Redefinir
                </button>
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Salvar
                </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>