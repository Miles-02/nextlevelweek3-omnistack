<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Funcionario Edit</h3>
            </div>
			<?php echo form_open('funcionario/edit/'.$funcionario['idfuncionario']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="codigo" class="control-label">Codigo</label>
						<div class="form-group">
							<input type="text" name="codigo" value="<?php echo ($this->input->post('codigo') ? $this->input->post('codigo') : $funcionario['codigo']); ?>" class="form-control" id="codigo" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="senha" class="control-label">Senha</label>
						<div class="form-group">
							<input type="text" name="senha" value="<?php echo ($this->input->post('senha') ? $this->input->post('senha') : $funcionario['senha']); ?>" class="form-control" id="senha" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="empresa_idempresa" class="control-label">Empresa Idempresa</label>
						<div class="form-group">
							<input type="text" name="empresa_idempresa" value="<?php echo ($this->input->post('empresa_idempresa') ? $this->input->post('empresa_idempresa') : $funcionario['empresa_idempresa']); ?>" class="form-control" id="empresa_idempresa" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="pessoa_idpessoa" class="control-label">Pessoa Idpessoa</label>
						<div class="form-group">
							<input type="text" name="pessoa_idpessoa" value="<?php echo ($this->input->post('pessoa_idpessoa') ? $this->input->post('pessoa_idpessoa') : $funcionario['pessoa_idpessoa']); ?>" class="form-control" id="pessoa_idpessoa" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>