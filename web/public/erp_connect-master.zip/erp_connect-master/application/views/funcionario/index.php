<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Funcionários</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('funcionario/add'); ?>" class="btn btn-success btn-sm">Inserir</a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Código do funcionário</th>
                        <th>Nome</th>
						<th>Empresa</th>
						<th>Ações</th>
                    </tr>
                    <?php foreach($funcionario as $f){ ?>
                    <tr>
						<td><?php echo $f['codigo']; ?></td>
                        <td><?php echo $f['nome']; ?></td>
						<td><?php echo $f['empresa']; ?></td>
						<td>
                            <a href="<?php if($f['gerente']==0){
                            echo site_url('funcionario/adicionar_gerente/'.$f['idfuncionario']);
                            }else{
                                echo site_url('funcionario/remover_gerente/'.$f['idfuncionario']);
                            } ?>"
                            <?php if($f['gerente'] == 0){
                                echo 'class="btn btn-success btn-xs"><span class="fa fa-user"></span> ';
                            }
                            else{
                                echo 'class="btn btn-danger btn-xs"><span class="fa fa-user"></span> ';
                            } ?>

                            <?php if($f['gerente'] == 0){
                                echo 'Tornar gerente';
                            } else{
                                echo 'Remover gerente';
                            }
                            ?>
                            </a>
                            <?php if($f['gerente'] == 1): ?>
                                <a href="" class="btn btn-info btn-xs"><span class="fa fa-lock"></span> Cadastrar senha gerencial</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
