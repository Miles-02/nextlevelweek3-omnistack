<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">Editar serviço</h3>
            </div>
            <?php echo form_open('servicoEvento/edit/'.$servicoEvento['idservicoEvento']); ?>
            <div class="box-body">
                <div class="col-md-6">
                    <label for="servico_idservico" class="control-label">Serviço</label>
                    <div class="form-group">
                        <input type="text" name="servico_idservico" value="<?php echo ($this->input->post('servico_idservico') ? $this->input->post('servico_idservico') : $servicoEvento['servico']); ?>" class="form-control" id="codigo" disabled/>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="quantidade" class="control-label">Quantidade</label>
                    <div class="form-group">
                        <input type="text" name="quantidade" value="<?php echo ($this->input->post('quantidade') ? $this->input->post('quantidade') : $servicoEvento['quantidade']); ?>" class="form-control" id="quantidade" />
                    </div>
                </div>
            </div>
            <div class="box-footer text-right">
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Salvar
                </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>