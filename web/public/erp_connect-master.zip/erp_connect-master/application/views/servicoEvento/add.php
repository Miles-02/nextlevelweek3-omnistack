<div class="box-header">
    <h4 class="box-title text center">Serviços disponíveis no evento</h4><hr align="left">
</div>
<div class="box-body">
    <div class="row clearfix">
        <div class="col-md-4">
            <label for="servico_idservico" class="control-label">Serviço</label>
            <select name="servico_idservico" class="form-control">
                <option value="">Selecione</option>
                <?php
                foreach($all_servico as $servico)
                {
                    $selected = ($servico['idservico'] == $this->input->post('servico_idservico')) ? ' selected="selected"' : "";

                    echo '<option value="'.$servico['idservico'].'" '.$selected.'>'.$servico['tipo'].'</option>';
                }
                ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="quantidade" class="control-label">Quantidade</label>
            <div class="form-group">
                <input type="text" name="quantidade" value="<?php echo $this->input->post('quantidade'); ?>" class="form-control" id="quantidade" />
            </div>
        </div>
    </div>
</div>
