<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Serviços disponíveis no evento</h3>
                <div class="box-tools">
                    <a href="<?php echo site_url('servicoEvento/add'); ?>" class="btn btn-success btn-sm"><span class="fa fa-plus"></span></a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>Evento</th>
                        <th>Serviço</th>
                        <th>Quantidade</th>
                        <th>Ações</th>
                    </tr>
                    <?php foreach($servicoEvento as $se){ ?>
                        <tr>
                            <td><?php echo $se['evento']; ?></td>
                            <td><?php echo $se['servico']; ?></td>
                            <td><?php echo $se['quantidade']; ?></td>
                            <td>
                                <a href="<?php echo site_url('servicoEvento/edit/'.$se['idservicoEvento']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Alterar</a>
                                <a href="<?php echo site_url('servicoEvento/remove/'.$se['idservicoEvento']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Excluir</a>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
