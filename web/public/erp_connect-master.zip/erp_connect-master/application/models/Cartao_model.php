<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Cartao_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_cartao($idcartao)
    {
        return $this->db->get_where('cartao',array('idcartao'=>$idcartao))->row_array();
    }

    function pesquisarCartao($registro){
        $this->db->select("idcartao, registro, saldo, cartao.status")
            ->from("cartao")
            ->where('cartao.registro', $registro);

        return $this->db->get()->row_array();
    }

    function get_all_cartao_count()
    {
        $this->db->from('cartao');
        return $this->db->count_all_results();
    }

    function get_all_cartao($params = array())
    {
        $this->db->order_by('idcartao', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idcartao, registro, saldo, status, pessoa.nome as pessoa")
            ->from("cartao")
            ->join('cliente', 'cliente.idcliente = cartao.cliente_idcliente')
            ->join('pessoa', 'pessoa.idpessoa = cliente.pessoa_idpessoa');
        return $this->db->get()->result_array();
    }

    function add_cartao($params)
    {
        $this->db->insert('cartao',$params);
        return $this->db->insert_id();
    }

    function update_cartao($idcartao,$params)
    {
        $this->db->where('idcartao',$idcartao);
        return $this->db->update('cartao',$params);
    }


    function delete_cartao($idcartao)
    {
        return $this->db->delete('cartao',array('idcartao'=>$idcartao));
    }
}
