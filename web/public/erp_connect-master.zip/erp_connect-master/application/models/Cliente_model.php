<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Cliente_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get cliente by idcliente
     */
    function get_cliente($idcliente)
    {
        return $this->db->get_where('cliente',array('idcliente'=>$idcliente))->row_array();
    }
    
    /*
     * Get all cliente count
     */
    function get_all_cliente_count()
    {
        $this->db->from('cliente');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all cliente
     */
    function get_all_cliente($params = array())
    {
        $this->db->order_by('idcliente', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idcliente, cliente.cpf, cliente.senha, pessoa_idpessoa, pessoa.nome as nome, pessoa.sexo as sexo")
            ->from("cliente")
            ->join('pessoa', 'pessoa.idpessoa = cliente.pessoa_idpessoa');
        return $this->db->get()->result_array();
    }
        
    /*
     * function to add new cliente
     */
    function add_cliente($params)
    {
        $this->db->insert('cliente',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update cliente
     */
    function update_cliente($idcliente,$params)
    {
        $this->db->where('idcliente',$idcliente);
        return $this->db->update('cliente',$params);
    }
    
    /*
     * function to delete cliente
     */
    function delete_cliente($idcliente)
    {
        return $this->db->delete('cliente',array('idcliente'=>$idcliente));
    }
}
