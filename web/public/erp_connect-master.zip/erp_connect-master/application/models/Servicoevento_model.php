<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Servicoevento_model extends CI_Model{

    function __construct()
    {
        parent::__construct();
    }

    function get_servicoEvento($idservicoEvento)
    {
        $this->db->select("idservicoEvento, servicoEvento.quantidade, servico.tipo as servico")
            ->from("servicoevento")
            ->join('servico', 'servico.idservico=servicoevento.servico_idservico')
            ->where('servicoevento.idservicoEvento', $idservicoEvento);

        return $this->db->get()->row_array();
    }

    function get_evento_por_servico($idservicoEvento)
    {
        $this->db->select("evento_idevento")
            ->from("servicoevento")
            ->where('idservicoEvento', $idservicoEvento);
        return $this->db->get()->row_array();
    }

    function get_servicos_por_evento($idevento)
    {
        $this->db->select("idservicoEvento, servicoevento.quantidade, servico.nome as servico")
            ->from("servicoevento")
            ->join('servico', 'servico.idservico=servicoevento.servico_idservico')
            ->where('servicoevento.evento_idevento', $idevento);
            
        return $this->db->get()->result_array();
    }
    function get_qtd_servicos_por_evento($idevento,$tiposervico)
    {
        $this->db->from('servicoevento')
            ->where('servicoevento.evento_idevento', $idevento)
            ->where('servicoevento.servico_idservico', $tiposervico);

        return $this->db->count_all_results();
    }

    function get_all_servicoEvento_count()
    {
        $this->db->from('servicoevento');
        return $this->db->count_all_results();
    }

    function get_all_servicoEvento($params = array())
    {
        $this->db->order_by('idservicoEvento', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idservicoEvento, servicoevento.quantidade, servico.tipo as servico, evento.titulo as evento")
            ->from("servicoevento")
            ->join('evento', 'evento.idevento = servicoevento.evento_idevento')
            ->join('servico', 'servico.idservico = servicoevento.servico_idservico');
        return $this->db->get()->result_array();
    }

    function add_servicoEvento($params)
    {
        $this->db->insert('servicoevento',$params);
        return $this->db->insert_id();
    }

    function update_servicoEvento($idservicoEvento,$params)
    {
        $this->db->where('idservicoEvento',$idservicoEvento);
        return $this->db->update('servicoevento',$params);
    }

    function delete_servicoEvento($idservicoEvento)
    {
        return $this->db->delete('servicoevento',array('idservicoEvento'=>$idservicoEvento));
    }

}