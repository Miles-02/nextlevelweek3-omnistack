<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Comanda_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_comanda($idcomanda)
    {
        return $this->db->get_where('comanda',array('idcomanda'=>$idcomanda))->row_array();
    }

    function get_all_comanda_count()
    {
        $this->db->from('comanda');
        return $this->db->count_all_results();
    }

    function get_all_comanda($params = array())
    {
        $this->db->order_by('idcomanda', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('comanda')->result_array();
    }
    function get_count_comanda_evento($idevento){
        $this->db->select("idcomanda, cartao_idcartao, comanda.evento_idevento")
            ->from("comanda")
            ->where('comanda.evento_idevento', $idevento)
            ->group_by('comanda.cartao_idcartao');
        return $this->db->count_all_results();
    }
    function get_comanda_cartao($idcartao, $idevento){
        $this->db->select("idcomanda, total, saldo, status, hora_abertura, hora_fechamento, cartao_idcartao, evento_idevento")
            ->from("comanda")
            ->where('comanda.evento_idevento', $idevento )
            ->where('comanda.cartao_idcartao', $idcartao )
            ->where('comanda.status', 1);
        return $this->db->get()->result_array();
    }
    function add_comanda($params)
    {
        $this->db->insert('comanda',$params);
        return $this->db->insert_id();
    }

    function update_comanda($idcomanda,$params)
    {
        $this->db->where('idcomanda',$idcomanda);
        return $this->db->update('comanda',$params);
    }

    function delete_comanda($idcomanda)
    {
        return $this->db->delete('comanda',array('idcomanda'=>$idcomanda));
    }
}
