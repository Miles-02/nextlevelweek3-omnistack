<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Produto_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_produto($idproduto)
    {
        return $this->db->get_where('produto',array('idproduto'=>$idproduto))->row_array();
    }

    function get_all_produto_count()
    {
        $this->db->from('produto');
        return $this->db->count_all_results();
    }

    function get_all_produto($params = array())
    {
        $this->db->order_by('idproduto', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idproduto, nome, descricao, valor, img, categoria")
            ->from("produto")
            ->where('idproduto > 0');
        return $this->db->get()->result_array();
    }

    function add_produto($params)
    {
        $this->db->insert('produto',$params);
        return $this->db->insert_id();
    }

    function update_produto($idproduto,$params)
    {
        $this->db->where('idproduto',$idproduto);
        return $this->db->update('produto',$params);
    }

    function delete_produto($idproduto)
    {
        return $this->db->delete('produto',array('idproduto'=>$idproduto));
    }
}
