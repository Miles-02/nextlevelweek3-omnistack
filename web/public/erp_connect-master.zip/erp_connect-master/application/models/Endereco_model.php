<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Endereco_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get endereco by idendereco
     */
    function get_endereco($idendereco)
    {
        return $this->db->get_where('endereco',array('idendereco'=>$idendereco))->row_array();
    }
    
    /*
     * Get all endereco count
     */
    function get_all_endereco_count()
    {
        $this->db->from('endereco');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all endereco
     */
    function get_all_endereco($params = array())
    {
        $this->db->order_by('idendereco', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('endereco')->result_array();
    }
        
    /*
     * function to add new endereco
     */
    function add_endereco($params)
    {
        $this->db->insert('endereco',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update endereco
     */
    function update_endereco($idendereco,$params)
    {
        $this->db->where('idendereco',$idendereco);
        return $this->db->update('endereco',$params);
    }
    
    /*
     * function to delete endereco
     */
    function delete_endereco($idendereco)
    {
        return $this->db->delete('endereco',array('idendereco'=>$idendereco));
    }
}
