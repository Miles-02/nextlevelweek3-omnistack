<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Venda_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_vendas($idvendas)
    {
        return $this->db->get_where('vendas',array('idvendas'=>$idvendas))->row_array();
    }

    function get_all_vendas()
    {
        $this->db->order_by('idvendas', 'desc');
        return $this->db->get('vendas')->result_array();
    }

    function get_total_consumo($idevento){
        $this->db->select("idvendas, produto_idproduto, servicoEvento_idservicoEvento, sum(vendas.total) as total_consumo")
            ->from("vendas")
            ->where('vendas.servicoEvento_idservicoEvento', 99999)
            ->where('vendas.evento_idevento', $idevento );
        return $this->db->get()->result_array();
    }
    function get_total_servico($idevento){
        $this->db->select("idvendas, produto_idproduto, servicoEvento_idservicoEvento, sum(vendas.total) as total_servico")
            ->from("vendas")
            ->where('vendas.produto_idproduto', 0)
            ->where('vendas.evento_idevento', $idevento);
        return $this->db->get()->result_array();
    }
    function get_total_vendas($idevento){
        $this->db->select("idvendas, produto_idproduto, servicoEvento_idservicoEvento, sum(vendas.total) as total_vendas")
            ->from("vendas")
            ->where('vendas.evento_idevento', $idevento);
        return $this->db->get()->result_array();
    }

    function add_vendas($params)
    {
        $this->db->insert('vendas',$params);
        return $this->db->insert_id();
    }

    function update_vendas($idvendas,$params)
    {
        $this->db->where('idvendas',$idvendas);
        return $this->db->update('vendas',$params);
    }

    function update_vendas_cartao($idcartao,$params)
    {
        $this->db->where('cartao_idcartao',$idcartao);
        return $this->db->update('vendas',$params);
    }
}