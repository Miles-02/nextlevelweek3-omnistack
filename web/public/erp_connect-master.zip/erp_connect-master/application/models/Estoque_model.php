<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Estoque_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get estoque by idestoque
     */
    function get_estoque($idestoque)
    {
        return $this->db->get_where('estoque',array('idestoque'=>$idestoque))->row_array();
    }
    
    /*
     * Get all estoque count
     */
    function get_all_estoque_count()
    {
        $this->db->from('estoque');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all estoque
     */
    function get_all_estoque($params = array())
    {
        $this->db->order_by('idestoque', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idestoque, produto.nome as produto, quantidade")
            ->from("estoque")
            ->join('produto', 'produto.idproduto = estoque.produto_idproduto');
        return $this->db->get()->result_array();
    }
        
    /*
     * function to add new estoque
     */
    function add_estoque($params)
    {
        $this->db->insert('estoque',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update estoque
     */
    function update_estoque($idestoque,$params)
    {
        $this->db->where('idestoque',$idestoque);
        return $this->db->update('estoque',$params);
    }
    
    /*
     * function to delete estoque
     */
    function delete_estoque($idestoque)
    {
        return $this->db->delete('estoque',array('idestoque'=>$idestoque));
    }
}
