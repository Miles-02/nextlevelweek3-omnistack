<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Login_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function logar($codigo, $senha)
    {
        $this->db->select('*');
        $this->db->from('funcionario');
        $this->db->where('codigo', $codigo);
        $this->db->where('senha', $senha);
        $this->db->where('administrativo','1');
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->result();
    }
}
