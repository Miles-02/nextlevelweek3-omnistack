<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Evento_model extends CI_Model{

    function __construct()
    {
        parent::__construct();
    }

    function get_evento($idevento)
    {
        return $this->db->get_where('evento',array('idevento'=>$idevento))->row_array();
    }

    function get_evento_aberto_count(){
        $this->db->from('evento')
            ->where('status', 1);
        return $this->db->count_all_results();
    }

    function get_all_evento_count()
    {
        $this->db->from('evento');
        return $this->db->count_all_results();
    }
    function get_evento_aberto_empresa_count($idempresa){
        $this->db->from('evento')
            ->where('empresa_idempresa', $idempresa)
            ->where('evento.status', 1);
        return $this->db->count_all_results();
    }
    function get_evento_aberto_empresa($idempresa){
        $this->db->from('evento')
            ->where('empresa_idempresa', $idempresa)
            ->where('evento.status', 1);
        return $this->db->get()->result_array();
    }
    function get_evento_aberto($idevento)
    {
        $this->db->from('evento')
            ->where('idevento', $idevento)
            ->where('status', 1);
        return $this->db->row_array();
    }
    function get_all_evento_aberto()
    {
        $this->db->select("idevento, titulo, descricao, data, artista, evento.status, evento.contador, empresa_idempresa, empresa.nome as empresa")
            ->from("evento")
            ->join('empresa', 'empresa.idempresa = evento.empresa_idempresa')
            ->where('evento.status', 1);
        return $this->db->get()->result_array();
    }

    function get_all_evento_sem_paginacao(){
        $this->db->select("idevento, titulo, descricao, data, artista, evento.status, evento.contador, empresa_idempresa, empresa.nome as empresa")
            ->from("evento")
            ->join('empresa', 'empresa.idempresa = evento.empresa_idempresa');
        return $this->db->get()->result_array();
    }
    function get_all_evento($params = array())
    {
        $this->db->order_by('idevento', 'desc');
        if(isset($params) && !empty($params)) {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idevento, titulo, descricao, data, artista, evento.status, evento.contador, empresa_idempresa, empresa.nome as empresa")
            ->from("evento")
            ->join('empresa', 'empresa.idempresa = evento.empresa_idempresa');
        return $this->db->get()->result_array();
    }
    function add_evento($params)
    {
        $this->db->insert('evento',$params);
        return $this->db->insert_id();
    }

    function update_evento($idevento,$params)
    {
        $this->db->where('idevento',$idevento);
        return $this->db->update('evento',$params);
    }

    function delete_evento($idevento)
    {
        return $this->db->delete('evento',array('idevento'=>$idevento));
    }


}