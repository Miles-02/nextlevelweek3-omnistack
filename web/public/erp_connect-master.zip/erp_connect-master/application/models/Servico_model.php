<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Servico_model extends CI_Model{
    function __construct()
    {
        parent::__construct();
    }

    function get_servico($idservico)
    {
        return $this->db->get_where('servico',array('idservico'=>$idservico))->row_array();
    }


    function get_all_servico_count()
    {
        $this->db->from('servico');
        return $this->db->count_all_results();
    }


    function get_all_servico($params = array())
    {
        $this->db->order_by('idservico', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idservico, codigoservico, nome, consumacao, entrada")
            ->from("servico")
            ->where('idservico != 99999');
        return $this->db->get()->result_array();
    }


    function add_servico($params)
    {
        $this->db->insert('servico',$params);
        return $this->db->insert_id();
    }


    function update_servico($idservico,$params)
    {
        $this->db->where('idservico',$idservico);
        return $this->db->update('servico',$params);
    }


    function delete_servico($idservico)
    {
        return $this->db->delete('servico',array('idservico'=>$idservico));
    }
}