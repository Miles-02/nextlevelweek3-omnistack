<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tipo_pagamento_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_tipo_pagamento($idtipo_pagamento)
    {
        return $this->db->get_where('tipo_pagamento',array('idtipo_pagamento'=>$idtipo_pagamento))->row_array();
    }

    function get_all_tipo_pagamento()
    {
        return $this->db->get('tipo_pagamento')->result_array();
    }

    function add_tipo_pagamento($params)
    {
        $this->db->insert('tipo_pagamento',$params);
        return $this->db->insert_id();
    }

    function update_tipo_pagamento($idtipopagamento,$params)
    {
        $this->db->where('idtipo_pagamento',$idtipopagamento);
        return $this->db->update('tipo_pagamento',$params);
    }
}