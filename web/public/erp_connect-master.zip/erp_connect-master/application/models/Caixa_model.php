<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Caixa_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_caixa($idcaixa)
    {
        return $this->db->get_where('caixa',array('idcaixa'=>$idcaixa))->row_array();
    }

    function get_all_caixa_count()
    {
        $this->db->from('caixa');
        return $this->db->count_all_results();
    }

    function get_registros_caixa($idevento)
    {
        $this->db->from('caixa')
            ->where('caixa.evento_idevento', $idevento);
        return $this->db->count_all_results();
    }

    function get_all_caixa($params = array())
    {
        $this->db->order_by('idcaixa', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('caixa')->result_array();
    }

    function add_caixa($params)
    {
        $this->db->insert('caixa',$params);
        return $this->db->insert_id();
    }

    function update_caixa($idcaixa,$params)
    {
        $this->db->where('idcaixa',$idcaixa);
        return $this->db->update('caixa',$params);
    }

    function delete_caixa($idcaixa)
    {
        return $this->db->delete('caixa',array('idcaixa'=>$idcaixa));
    }
}
