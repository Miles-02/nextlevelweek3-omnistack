<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Empresa_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get empresa by idempresa
     */
    function get_empresa($idempresa)
    {
        return $this->db->get_where('empresa',array('idempresa'=>$idempresa))->row_array();
    }
    
    /*
     * Get all empresa count
     */
    function get_all_empresa_count()
    {
        $this->db->from('empresa');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all empresa
     */
    function get_all_empresa($params = array())
    {
        $this->db->order_by('idempresa', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idempresa, nome, cnpj, status, endereco.cidade as endereco")
            ->from("empresa")
            ->join('endereco', 'endereco.idendereco = empresa.endereco_idendereco');
        return $this->db->get()->result_array();
    }
        
    /*
     * function to add new empresa
     */
    function add_empresa($params)
    {
        $this->db->insert('empresa',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update empresa
     */
    function update_empresa($idempresa,$params)
    {
        $this->db->where('idempresa',$idempresa);
        return $this->db->update('empresa',$params);
    }
    
    /*
     * function to delete empresa
     */
    function delete_empresa($idempresa)
    {
        return $this->db->delete('empresa',array('idempresa'=>$idempresa));
    }
}
