<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Funcionario_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_funcionario($idfuncionario)
    {
        return $this->db->get_where('funcionario',array('idfuncionario'=>$idfuncionario))->row_array();
    }
    function get_funcionario_api($idfuncionario)
    {
        $this->db->from('funcionario')
            ->where('funcionario.idfuncionario', $idfuncionario);
        return $this->db->get()->result_array();
    }
    function get_all_funcionario_count()
    {
        $this->db->from('funcionario');
        return $this->db->count_all_results();
    }

    function get_all_funcionario($params = array())
    {
        $this->db->order_by('idfuncionario', 'desc');
        if(isset($params) && !empty($params)) {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idfuncionario, funcionario.nome, funcionario.codigo, empresa_idempresa, funcionario.senha, gerente, empresa.nome as empresa")
            ->from("funcionario")
            ->join('empresa', 'empresa.idempresa = funcionario.empresa_idempresa');
        return $this->db->get()->result_array();
    }
    function get_funcionario_empresa_count($idempresa){
        $this->db->from('funcionario')
            ->where('empresa_idempresa', $idempresa );
        return $this->db->count_all_results();
    }
    function get_funcionario_empresa($params = array(), $idempresa){
        $this->db->order_by('idfuncionario', 'desc');
        if(isset($params) && !empty($params)) {
            $this->db->limit($params['limit'], $params['offset']);
        }
        $this->db->select("idfuncionario, funcionario.nome, funcionario.codigo, empresa_idempresa, funcionario.senha, gerente, empresa.nome as empresa")
            ->from("funcionario")
            ->join('empresa', 'empresa.idempresa = funcionario.empresa_idempresa')
            ->where('empresa_idempresa', $idempresa );
        return $this->db->get()->result_array();
    }
    function add_funcionario($params)
    {
        $this->db->insert('funcionario',$params);
        return $this->db->insert_id();
    }

    function update_funcionario($idfuncionario,$params)
    {
        $this->db->where('idfuncionario',$idfuncionario);
        return $this->db->update('funcionario',$params);
    }

    function delete_funcionario($idfuncionario)
    {
        return $this->db->delete('funcionario',array('idfuncionario'=>$idfuncionario));
    }
}
