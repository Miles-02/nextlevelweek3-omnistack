<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();

$autoload['libraries'] = array('database', 'session','pagination');

$autoload['drivers'] = array();

$autoload['helper'] = array('funcoes_helper','security','form','url');

$autoload['config'] = array('pagination');

$autoload['language'] = array();

$autoload['model'] = array();
