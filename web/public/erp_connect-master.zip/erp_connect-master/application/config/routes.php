<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$route['default_controller'] = 'login/login';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['autentica'] = 'login/autentica';
$route['logout'] = 'login/logout';

$route['api/get_comanda'] = 'API/get_comanda';


